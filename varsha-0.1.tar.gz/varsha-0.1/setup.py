import setuptools

setuptools.setup(
    name='varsha',
      version='0.1',
      description='The funniest joke in the world',
      author='Flying Circus',
      author_email='flyingcircus@example.com',
      license='MIT',
      packages=setuptools.find_packages()
)