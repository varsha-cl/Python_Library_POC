import setuptools
setuptools.setup(
    name="library_POC",
    version="0.0.1",
    author="varsha",
    author_email="clvarsha1998@gmail.com",
    description="A example package",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)