def hello():
   print("Python library")